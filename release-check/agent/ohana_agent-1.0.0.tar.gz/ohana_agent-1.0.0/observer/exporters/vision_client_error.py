"""Errors raised while communicating with Ohana-Vision."""


class VisionClientError(RuntimeError):
    """Raised when an observation cannot be sent to Ohana-Vision."""
