"""Capability package."""
