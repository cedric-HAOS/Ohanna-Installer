# Ohanna-Installer

> Installateur officiel de l'écosystème Ohanna.

## Présentation

**Ohanna-Installer** est le composant chargé d'installer, de mettre à jour et de désinstaller les produits officiels de l'écosystème **Ohanna**.

Il automatise le déploiement d'une plateforme complète à partir des releases officielles publiées sur GitHub, sans contenir la logique métier des composants qu'il installe.

À terme, un nouvel utilisateur doit pouvoir installer une plateforme Ohanna entièrement fonctionnelle à l'aide d'une seule commande.

---

# Écosystème

Ohanna est composé de quatre projets complémentaires :

| Projet               | Rôle                                                            |
| -------------------- | --------------------------------------------------------------- |
| **Ohanna-Platform**  | Architecture, documentation, contrats publics et Design System. |
| **Ohanna-Agent**     | Collecte les observations et surveille l'infrastructure.        |
| **Ohanna-Vision**    | Visualise les observations, l'état de santé et la topologie.    |
| **Ohanna-Installer** | Installe, met à jour et désinstalle les composants officiels.   |

Chaque projet possède une responsabilité clairement définie.

---

# Objectifs

Ohanna-Installer poursuit quatre objectifs principaux :

* simplifier le déploiement de la plateforme ;
* garantir des installations reproductibles ;
* centraliser les mises à jour des composants ;
* proposer une procédure d'installation identique sur toutes les machines supportées.

---

# Fonctionnalités

La version **1.0.0** fournit trois commandes principales :

```text
ohanna install
ohanna update
ohanna uninstall
```

## Installation

La commande :

```bash
ohanna install
```

réalise automatiquement :

* la vérification de l'environnement ;
* le téléchargement des releases officielles ;
* l'installation d'Ohanna-Agent ;
* l'installation d'Ohanna-Vision ;
* la génération des fichiers de configuration ;
* l'installation des services système ;
* la validation finale de l'installation.

---

## Mise à jour

La commande :

```bash
ohanna update
```

recherche les nouvelles releases officielles et met à jour les composants installés.

---

## Désinstallation

La commande :

```bash
ohanna uninstall
```

supprime proprement les composants installés ainsi que les services associés.

---

# Philosophie

Ohanna-Installer ne contient aucune logique métier.

Il ne surveille pas l'infrastructure.

Il ne collecte pas d'observations.

Il ne fournit aucune interface utilisateur.

Son unique responsabilité consiste à gérer le cycle de vie des composants officiels de l'écosystème Ohanna.

Cette séparation garantit un faible couplage entre les différents projets et facilite leur évolution indépendante.

---

# Architecture

Le processus d'installation suit le principe suivant :

```text
GitHub Releases
        │
        ▼
Téléchargement des composants
        │
        ▼
Installation
        │
        ▼
Configuration
        │
        ▼
Création des services
        │
        ▼
Validation
```

Les installations s'appuient exclusivement sur des **releases officielles**, garantissant un déploiement reproductible et indépendant des branches de développement.

---

# Compatibilité

La version 1.0.0 est conçue pour les environnements Linux utilisant **systemd**.

Les composants installés sont :

* Ohanna-Agent ;
* Ohanna-Vision.

---

# Développement

Création d'un environnement virtuel :

```bash
python -m venv .venv
```

Activation :

### Linux

```bash
source .venv/bin/activate
```

### Windows

```powershell
.venv\Scripts\Activate.ps1
```

Installation des dépendances :

```bash
pip install -e .
```

Lancement des tests :

```bash
pytest
```

---

# Documentation

La documentation du projet est disponible dans le répertoire `docs/`.

Les principales ressources sont :

* `ROADMAP.md`
* `CHANGELOG.md`
* documentation d'architecture
* guides d'installation

---

# Licence

Ce projet est distribué sous licence **MIT**.

Cette base reste volontairement concise et centrée sur la mission d'Ohanna-Installer, en cohérence avec les README des autres projets de l'écosystème.
