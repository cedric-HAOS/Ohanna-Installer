"""Tests de l'interface en ligne de commande."""

from __future__ import annotations

import pytest

from ohanna_installer.cli import main
from ohanna_installer.version import __version__


def test_cli_returns_success_without_arguments() -> None:
    assert main([]) == 0


def test_cli_displays_version(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--version"])

    assert exc_info.value.code == 0
    assert capsys.readouterr().out.strip() == f"ohanna {__version__}"


def test_cli_displays_help(capsys: pytest.CaptureFixture[str]) -> None:
    with pytest.raises(SystemExit) as exc_info:
        main(["--help"])

    assert exc_info.value.code == 0

    output = capsys.readouterr().out
    assert "usage: ohanna" in output
    assert "--version" in output