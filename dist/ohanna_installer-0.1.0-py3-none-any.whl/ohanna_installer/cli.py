"""Interface en ligne de commande d'Ohanna-Installer."""

from __future__ import annotations

import argparse
from collections.abc import Sequence

from ohanna_installer.version import __version__


def build_parser() -> argparse.ArgumentParser:
    """Construire le parseur principal de la CLI."""

    parser = argparse.ArgumentParser(
        prog="ohanna",
        description=(
            "Installer, mettre à jour et désinstaller les composants "
            "officiels de l'écosystème Ohanna."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Exécuter l'interface en ligne de commande."""

    parser = build_parser()
    parser.parse_args(argv)
    return 0